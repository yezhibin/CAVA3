#!/bin/sh

cd ..
cava client_no_limit=9 execution_plan=first_var testdatas=/usr/local/bin/CAVA3/CAVA_SPACE3/testcases/Camera_Dome/07-Public_Stability/Creat_CRT_IniFile_Tool/DeviceList.xls Creat_CRT_IniFile_Tool/src

