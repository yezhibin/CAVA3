#!/bin/sh
cd ./output
rm -rf *.ini